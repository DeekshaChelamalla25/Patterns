package Demo15;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class Demo15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hashtable<Integer,String> ht = new Hashtable<Integer,String>();
		ht.put(101, "Deeksha");
		ht.put(101, "Nani");
		ht.put(102, "Neelima");
		ht.put(103, "Nageshwar");
		System.out.println("----------Hash table-----------");
		for(Map.Entry m:ht.entrySet()) {
			System.out.println(m.getKey()+" "+m.getValue());
		}
		HashMap<Integer,String> hm= new HashMap<Integer,String>();
		hm.put(100, "Abhi");
		hm.put(104, "Shanaya");
		hm.put(101, "Krisha");
		hm.put(102, "Gosha");
		System.out.println("-----------Hash Map---------");
		for(Map.Entry m:hm.entrySet()) {
			System.out.println(m.getKey()+" "+m.getValue());
		}
	}

}
