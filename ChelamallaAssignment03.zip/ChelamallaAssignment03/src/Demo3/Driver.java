package Demo3;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SuperClass s1 = new SuperClass();
		SubClass s2 = new SubClass();
		SuperClass obj1 = s1.method(); 
        SuperClass obj2 = s2.method();
	}

}
