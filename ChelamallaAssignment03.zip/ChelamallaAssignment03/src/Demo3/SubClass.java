package Demo3;

public class SubClass extends SuperClass {
	public SubClass method() {
        System.out.println("SubClass");
        return new SubClass();
    }
}
