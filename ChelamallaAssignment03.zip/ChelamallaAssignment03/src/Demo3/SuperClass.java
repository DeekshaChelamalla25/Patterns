package Demo3;

public class SuperClass {
	public SuperClass method() {
        System.out.println("SuperClass");
        return new SuperClass();
    }
}
