package Demo7;

public class Demo7 {
	public final String name = " Sam";
	   public final int age= 22;
	   public final Demo7(){
	      this.name = "Sam";
	      this.age = 20;
	   }
	   public void display(){
	      System.out.println("Name of the Student: "+this.name );
	      System.out.println("Age of the Student: "+this.age );
	   }
	  public static void main(String[] args) {
		// TODO Auto-generated method stub
		  new Demo7().display();

	}

}
