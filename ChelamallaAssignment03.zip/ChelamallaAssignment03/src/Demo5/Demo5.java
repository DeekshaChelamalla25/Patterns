package Demo5;

public class Demo5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer s = new StringBuffer("Hello ");
        s.append("Patterns"); 
        System.out.println(s);
        StringBuilder s1 = new StringBuilder("Hello ");
        s1.delete(1,3); 
        System.out.println(s1);
	}

}
