package Demo25;

interface Say{
	void say();
}

interface Sayable{
	public String say(String name) ;
}
public class Demo25 {
	public static void saySomething() {
		System.out.println("This is the feature of Java 8 ");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sayable s =(name)->{
			return "Hello: " +name;
		};
		System.out.println(s.say("S"));
		
		Sayable s1=name->{
			return "Hello: "+name;
		};
		System.out.println(s1.say("S1"));
		
		Say s2 = Demo25::saySomething;
		s2.say();
		
	}

}
