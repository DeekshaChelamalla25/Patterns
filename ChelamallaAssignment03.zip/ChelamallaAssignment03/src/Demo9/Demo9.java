package Demo9;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;

public class Demo9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try (FileOutputStream fos = new FileOutputStream("outputfile.txt");

		         
		         BufferedReader br = new BufferedReader (new FileReader("inputfile.txt"))) {
		           String text;

		       
		        while ((text = br.readLine()) != null) {
		        	byte arr[] = text.getBytes();

		            fos.write(arr);

		        }
		        System.out.println("File content copied to another one.");
		    } catch (Exception e) {
		       System.out.println(e);
		    }

		    
		    System.out.println( "Resource are closed and message has been written into the inputfile.txt");

	}

}
