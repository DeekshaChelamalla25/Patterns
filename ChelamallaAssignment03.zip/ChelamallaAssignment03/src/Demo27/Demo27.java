package Demo27;

public class Demo27 {
    private static volatile Demo27 instance;
    
    private Demo27() {
        
    }
    
    public static synchronized Demo27 getInstance() {
        if (instance == null) {
            synchronized (Demo27.class) {
                if (instance == null) {
                    instance = new Demo27();
                }
            }
        }
        return instance;
    }
}
