package Demo8;

public class Demo8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		  {
		   System.out.println("Executing try block");
		  }
		  finally
		  {
		   System.out.println("Executing finally block");
		  }

	}

}
