package Demo2;

public class SubClass extends SuperClass {
	public void method()
	{
	System.out.println("Scope can be changed in overriden method");	
	}
	
	public static void main(String[] args) {
		SubClass a = new SubClass();
		a.method();
	}

}
