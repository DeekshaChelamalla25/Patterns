package Demo2;

public class SuperClass {
	protected void method()
	{
		System.out.println("Yes, it is possible to change the scope of overriden method");
	}
}
