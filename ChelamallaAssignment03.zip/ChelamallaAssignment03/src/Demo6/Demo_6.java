package Demo6;

public class Demo_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Testing of Hashcode in String class");
		String s = "Deek";
		System.out.println(s.hashCode());
		s = s+"sha";
		System.out.println(s.hashCode());
		
		System.out.println("Testing of Hashcode in StringBuffer class");
		StringBuffer s1 = new StringBuffer("Hi");
		System.out.println(s1.hashCode());
		s1.append(" Everyone");
		System.out.println(s1.hashCode());
	}

}
