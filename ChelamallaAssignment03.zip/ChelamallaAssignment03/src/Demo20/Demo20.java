package Demo20;

public class Demo20 implements Runnable {
	public static Thread thread1;
	public static Demo20 obj;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			Thread.sleep(1000);
		}
		catch(InterruptedException  e) {
			e.printStackTrace();
			
		}
		System.out.println("State of thread1 while it joins thread2: " +Demo20.thread1.getState());
		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		obj = new Demo20();
		thread1 = new Thread(obj);
		
		System.out.println("State of thread after creating: " + thread1.getState());
		thread1.start();
	}

}
