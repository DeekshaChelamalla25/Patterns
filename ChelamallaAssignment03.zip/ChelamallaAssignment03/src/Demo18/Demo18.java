package Demo18;

public class Demo18 implements Runnable {
	 @Override
	   public void run(){  
		Thread t = Thread.currentThread();
	        System.out.println(t.getName()+" is executing.");
			    
	   }  
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread t1 = new Thread(new Demo18(), "t1"); 
		t1.start();  
		t1.start(); 

	}

}
