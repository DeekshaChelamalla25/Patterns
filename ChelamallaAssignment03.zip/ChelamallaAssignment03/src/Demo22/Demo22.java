package Demo22;

public class Demo22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "Hi";
		s = s.concat(" Deeksha");
		System.out.println(s);
	}

}
