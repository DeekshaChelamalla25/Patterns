package Demo16;

import java.util.HashMap;

public class Demo16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,String> hm= new HashMap<Integer,String>();
		hm.put( 7,"Deeksha");
		hm.put( 8,"Gopi");
		hm.put( 7,"Neelima");
		hm.put( 9,"Nageshwar");
		System.out.println("-----------Hash Map---------");
		System.out.println(hm.entrySet());
	}

}
