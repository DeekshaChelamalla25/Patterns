package Demo10;

class SuperClass
{
    void methodOfSuperClass()
    {
        System.out.println("Successful");
    }
}
 
class SubClass extends SuperClass
{
    @Override
    void methodOfSuperClass() throws ArrayIndexOutOfBoundsException
    {
        System.out.println("Can be overrided using throws with any exceptions");
    }
}
public class Demo10 {

	public static void main(String[] args) {
		SuperClass s1 = new SuperClass();
		SubClass s2 = new SubClass();
		s1.methodOfSuperClass();
		s2.methodOfSuperClass();

	}

}
