/**
 * 
 */
package Demo1;

/**
 * @author S554975
 *
 */
public class Demo_1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Double[] doubleArray = { 1.0, 2.0, 3.0 };
		String[] stringArray = { "Deeksha", "Yashu", "Gopi" };

		printArray(doubleArray);
		printArray(stringArray);
		
	}
	public static <T> void printArray(T[] arr) {
	    for (T element : arr) {
	        System.out.println(element);
	    }
	}
}
