package Demo4;

public class SubClass extends SuperClass {
	public static void staticMethod() {
        System.out.println("SubClass staticMethod");
    }

    private void privateMethod() {
        System.out.println("SubClass privateMethod");
    }
	public static void main(String[] args) {
		SuperClass superClass = new SuperClass();
        SubClass subClass = new SubClass();

        superClass.privateMethod(); 
        subClass.privateMethod();

	}

}
