package Demo14;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Demo14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> food = new ArrayList<String>();
		food.add("Biryani");
		food.add("PaniPuri");
		food.add("Gulab Jamun");
		
		food = Collections.synchronizedList(food);
		
		synchronized(food) {
			Iterator<String> s = food.iterator();
			while(s.hasNext()) {
				System.out.println(s.next());
			}
		}
	}

}
