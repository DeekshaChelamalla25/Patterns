package Demo13;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

public class Demo13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list =  new ArrayList<String>();
		list.add("Kansas City");
		list.add("St.Joseph");
		list.add("Dallas");
		
		System.out.println("ArrayList Elements");
		Iterator i = list.iterator();
		while (i.hasNext()) {
			System.out.println(i.next());
		}
		
		Vector<String> v = new Vector<String>();
		v.add("Kansas City");
		v.add("St.Joseph");
		v.add("Dallas");
		
		System.out.println("Vector Elements");
		Enumeration<String> e = v.elements();
		while(e.hasMoreElements()) {
			//System.out.println("1");
			System.out.println(e.nextElement());
		}
	}

}
