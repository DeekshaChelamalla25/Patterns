package Demo19;

public class Demo19 implements Runnable {
	public void run() {
		System.out.println("Thread is running from parent class");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo19 obj = new Demo19();
		Thread t1 = new Thread(obj);
		t1.start();
	}

}
